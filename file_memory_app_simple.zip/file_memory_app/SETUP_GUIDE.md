# File Memory App - Complete Setup Guide

This guide will walk you through setting up and running the File Memory app from scratch.

## Table of Contents
1. [System Requirements](#system-requirements)
2. [Installing Flutter](#installing-flutter)
3. [Setting Up Your IDE](#setting-up-your-ide)
4. [Running the Project](#running-the-project)
5. [Testing on Real Devices](#testing-on-real-devices)
6. [Common Issues and Solutions](#common-issues-and-solutions)

## System Requirements

### For Android Development
- **Operating System**: Windows 10/11, macOS, or Linux
- **RAM**: Minimum 8GB (16GB recommended)
- **Disk Space**: At least 10GB free space
- **Android Studio**: Latest version

### For iOS Development (macOS only)
- **Operating System**: macOS 10.15 or later
- **RAM**: Minimum 8GB (16GB recommended)
- **Xcode**: Latest version
- **CocoaPods**: Installed

## Installing Flutter

### Windows

1. **Download Flutter SDK**
   - Go to https://flutter.dev/docs/get-started/install/windows
   - Download the Flutter SDK zip file
   - Extract to `C:\src\flutter` (or your preferred location)

2. **Add Flutter to PATH**
   - Search for "Environment Variables" in Windows
   - Add `C:\src\flutter\bin` to your PATH
   - Restart your terminal

3. **Run Flutter Doctor**
   ```bash
   flutter doctor
   ```
   - Follow any instructions to install missing dependencies

### macOS

1. **Download Flutter SDK**
   ```bash
   cd ~/development
   wget https://storage.googleapis.com/flutter_infra_release/releases/stable/macos/flutter_macos_arm64_stable.zip
   unzip flutter_macos_arm64_stable.zip
   ```

2. **Add Flutter to PATH**
   - Edit your shell profile (`~/.zshrc` or `~/.bash_profile`):
   ```bash
   export PATH="$PATH:$HOME/development/flutter/bin"
   ```
   - Reload: `source ~/.zshrc`

3. **Run Flutter Doctor**
   ```bash
   flutter doctor
   ```

### Linux

1. **Download Flutter SDK**
   ```bash
   cd ~/development
   wget https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_stable.tar.xz
   tar xf flutter_linux_stable.tar.xz
   ```

2. **Add to PATH**
   ```bash
   echo 'export PATH="$PATH:$HOME/development/flutter/bin"' >> ~/.bashrc
   source ~/.bashrc
   ```

3. **Run Flutter Doctor**
   ```bash
   flutter doctor
   ```

## Setting Up Your IDE

### Visual Studio Code (Recommended for Beginners)

1. **Download and Install VS Code**
   - Go to https://code.visualstudio.com/

2. **Install Flutter Extension**
   - Open VS Code
   - Go to Extensions (Ctrl+Shift+X or Cmd+Shift+X)
   - Search for "Flutter"
   - Install the Flutter extension (also installs Dart extension)

3. **Verify Installation**
   - Press Ctrl+Shift+P (Cmd+Shift+P on Mac)
   - Type "Flutter: Run Flutter Doctor"
   - Check if everything is set up correctly

### Android Studio

1. **Download Android Studio**
   - Go to https://developer.android.com/studio
   - Download and install

2. **Install Flutter Plugin**
   - Open Android Studio
   - Go to Settings/Preferences → Plugins
   - Search for "Flutter" and install
   - Restart Android Studio

3. **Configure Android SDK**
   - Go to Settings → Appearance & Behavior → System Settings → Android SDK
   - Install the latest Android SDK Platform
   - Install Android SDK Build-Tools

## Running the Project

### 1. Clone/Download the Project

```bash
# If using Git
git clone <repository-url>
cd file_memory_app

# Or extract the downloaded ZIP file and navigate to it
cd file_memory_app
```

### 2. Install Dependencies

```bash
flutter pub get
```

This will download all required packages listed in `pubspec.yaml`.

### 3. Check Connected Devices

```bash
flutter devices
```

This shows all available devices (emulators and physical devices).

### 4. Run the App

#### On Emulator/Simulator

**Android Emulator:**
```bash
# Start Android Studio
# Go to AVD Manager (Tools → AVD Manager)
# Create and start a virtual device
# Then run:
flutter run
```

**iOS Simulator (macOS only):**
```bash
open -a Simulator
flutter run
```

#### On Physical Device

**Android:**
1. Enable Developer Options on your Android device:
   - Go to Settings → About Phone
   - Tap "Build Number" 7 times
   - Go back → Developer Options
   - Enable "USB Debugging"

2. Connect device via USB

3. Run:
   ```bash
   flutter run
   ```

**iOS (macOS only):**
1. Connect your iPhone via USB
2. Trust the computer on your device
3. Open Xcode and sign the app:
   ```bash
   open ios/Runner.xcworkspace
   ```
4. In Xcode, select your device and your development team
5. Run:
   ```bash
   flutter run
   ```

### 5. Hot Reload During Development

While the app is running:
- Press `r` in the terminal for hot reload
- Press `R` for hot restart
- Press `q` to quit

## Testing on Real Devices

### Android Testing

1. **Enable Developer Mode**
   - Settings → About Phone → Tap Build Number 7 times

2. **Enable USB Debugging**
   - Settings → Developer Options → USB Debugging

3. **Connect and Verify**
   ```bash
   adb devices
   flutter devices
   ```

4. **Run App**
   ```bash
   flutter run
   ```

### iOS Testing (macOS only)

1. **Register Device in Xcode**
   - Connect iPhone via USB
   - Open `ios/Runner.xcworkspace` in Xcode
   - Select your device from the device menu
   - Sign the app with your Apple Developer account

2. **Trust Developer on iPhone**
   - After first run: Settings → General → VPN & Device Management
   - Trust your developer certificate

3. **Run App**
   ```bash
   flutter run
   ```

## Common Issues and Solutions

### Issue: "Flutter command not found"
**Solution**: Make sure Flutter is in your PATH. Restart terminal after adding to PATH.

### Issue: "Android licenses not accepted"
**Solution**: 
```bash
flutter doctor --android-licenses
```
Accept all licenses by typing 'y'.

### Issue: "CocoaPods not installed" (macOS)
**Solution**:
```bash
sudo gem install cocoapods
cd ios
pod install
cd ..
```

### Issue: "Gradle build failed" (Android)
**Solution**:
```bash
cd android
./gradlew clean
cd ..
flutter clean
flutter pub get
flutter run
```

### Issue: "Permission denied" errors on Android
**Solution**: 
- Make sure AndroidManifest.xml has proper permissions
- Request permissions at runtime (app does this automatically)
- Check Android version compatibility (Android 6.0+)

### Issue: "Photo library access denied" on iOS
**Solution**:
- Check Info.plist has NSPhotoLibraryUsageDescription
- Delete app and reinstall to reset permissions
- Check Settings → Privacy → Photos on device

### Issue: Build failing due to outdated dependencies
**Solution**:
```bash
flutter clean
rm -rf ios/Pods ios/Podfile.lock
flutter pub get
cd ios && pod install && cd ..
flutter run
```

## Building Release Versions

### Android APK
```bash
flutter build apk --release
```
APK location: `build/app/outputs/flutter-apk/app-release.apk`

### Android App Bundle (Google Play)
```bash
flutter build appbundle --release
```

### iOS (macOS only)
```bash
flutter build ios --release
```
Then archive in Xcode: `Product → Archive`

## Next Steps

1. ✅ Run the app successfully
2. ✅ Test all features (scan, view, delete files)
3. 📝 Customize the app (colors, thresholds, etc.)
4. 🚀 Add new features
5. 📱 Deploy to app stores

## Getting Help

If you encounter issues not covered here:
1. Check the Flutter documentation: https://flutter.dev/docs
2. Search Stack Overflow: https://stackoverflow.com/questions/tagged/flutter
3. Open an issue on the GitHub repository
4. Join Flutter community on Discord: https://discord.gg/flutter

## Development Tips

1. **Use Hot Reload**: Speeds up development significantly
2. **Keep Flutter Updated**: `flutter upgrade`
3. **Use Flutter DevTools**: `flutter pub global activate devtools`
4. **Run Tests**: `flutter test`
5. **Check Performance**: Use Flutter DevTools profiler

Happy coding! 🚀
