# File Memory - Smart File Cleanup Assistant

A Flutter mobile app that helps users discover and manage forgotten files on their Android and iOS devices. The app scans photos and videos, identifies old files (6+ months), large files (50+ MB), and provides an easy interface to review and delete them.

## Features

- 📸 **Photo & Video Scanning**: Automatically scans all photos and videos on your device
- 🕐 **Old File Detection**: Identifies files older than 6 months
- 💾 **Large File Detection**: Finds files larger than 50 MB
- 📊 **Storage Analytics**: Visual breakdown of storage usage by category
- 🗑️ **Easy Cleanup**: Simple interface to review and delete unwanted files
- 🔔 **Smart Notifications**: Get reminders about old files
- 🎯 **Batch Operations**: Select and delete multiple files at once

## Screenshots

(Add screenshots here once you have them)

## Prerequisites

Before you begin, ensure you have the following installed:

- **Flutter SDK** (version 3.0.0 or higher) - [Install Flutter](https://docs.flutter.dev/get-started/install)
- **Android Studio** (for Android development)
- **Xcode** (for iOS development - macOS only)
- **Git**

## Installation

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/file_memory_app.git
cd file_memory_app
```

### 2. Install Dependencies

```bash
flutter pub get
```

### 3. Run the App

#### For Android:
```bash
flutter run
```

#### For iOS (macOS only):
```bash
cd ios
pod install
cd ..
flutter run
```

## Building for Release

### Android APK
```bash
flutter build apk --release
```

The APK will be located at: `build/app/outputs/flutter-apk/app-release.apk`

### Android App Bundle (for Google Play)
```bash
flutter build appbundle --release
```

### iOS
```bash
flutter build ios --release
```

Then open `ios/Runner.xcworkspace` in Xcode to archive and distribute.

## Project Structure

```
file_memory_app/
├── lib/
│   ├── main.dart                 # App entry point
│   ├── models/                   # Data models
│   │   └── tracked_file.dart
│   ├── services/                 # Business logic
│   │   ├── file_scanner_service.dart
│   │   └── notification_service.dart
│   ├── database/                 # Database operations
│   │   └── database_helper.dart
│   ├── screens/                  # UI screens
│   │   ├── home_screen.dart
│   │   ├── file_list_screen.dart
│   │   └── file_detail_screen.dart
│   └── widgets/                  # Reusable widgets
│       ├── storage_card.dart
│       └── category_card.dart
├── android/                      # Android-specific code
├── ios/                          # iOS-specific code
└── pubspec.yaml                  # Dependencies

```

## Key Dependencies

- **photo_manager**: Access and manage photos/videos
- **sqflite**: Local database for tracking files
- **provider**: State management
- **permission_handler**: Request device permissions
- **flutter_local_notifications**: Send notifications

## Permissions

### Android
The app requires the following permissions:
- `READ_MEDIA_IMAGES` - To scan photos
- `READ_MEDIA_VIDEO` - To scan videos
- `POST_NOTIFICATIONS` - To send reminders (Android 13+)
- `ACCESS_MEDIA_LOCATION` - To access media metadata

### iOS
- `NSPhotoLibraryUsageDescription` - To access photos library

## How It Works

1. **Scan**: The app requests photo library permissions and scans all accessible photos and videos
2. **Analyze**: Files are analyzed by age, size, and type
3. **Categorize**: Files are sorted into categories (Old Files, Large Files, Photos, Videos)
4. **Review**: Users can browse files by category and view details
5. **Cleanup**: Users can delete individual files or batch delete multiple files

## Customization

### Change Old File Threshold
Edit `lib/database/database_helper.dart`:
```dart
Future<List<TrackedFile>> getOldFiles({int monthsOld = 6}) async {
  // Change 6 to your desired number of months
}
```

### Change Large File Threshold
Edit `lib/database/database_helper.dart`:
```dart
Future<List<TrackedFile>> getLargeFiles({int minSizeMB = 50}) async {
  // Change 50 to your desired size in MB
}
```

## Troubleshooting

### Android Issues

**Problem**: Permission denied errors
- **Solution**: Make sure permissions are declared in `AndroidManifest.xml` and you're running on Android 6.0+

**Problem**: App crashes on Android 11+
- **Solution**: Ensure you're using scoped storage permissions (READ_MEDIA_IMAGES, READ_MEDIA_VIDEO)

### iOS Issues

**Problem**: Permission denied
- **Solution**: Check that `NSPhotoLibraryUsageDescription` is in `Info.plist`

**Problem**: Pod install fails
- **Solution**: 
  ```bash
  cd ios
  pod deintegrate
  pod install
  ```

### General Issues

**Problem**: Dependencies not installing
- **Solution**: 
  ```bash
  flutter clean
  flutter pub get
  ```

## Future Enhancements

- [ ] Duplicate photo detection
- [ ] Similar photo grouping
- [ ] Cloud backup integration
- [ ] Automatic cleanup scheduling
- [ ] More file types support (documents, downloads)
- [ ] Storage usage charts/graphs
- [ ] Export file lists

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

If you encounter any issues or have questions:
- Open an issue on GitHub
- Contact: your.email@example.com

## Acknowledgments

- Flutter team for the amazing framework
- All open-source package contributors
- Community for feedback and support

---

**Note**: This app only accesses files that the user explicitly grants permission to. All data is stored locally on the device and never uploaded to any server.
