import 'package:flutter/foundation.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/tracked_file.dart';
import '../database/database_helper.dart';

class FileScannerService extends ChangeNotifier {
  bool _isScanning = false;
  double _scanProgress = 0.0;
  List<TrackedFile> _allFiles = [];
  List<TrackedFile> _oldFiles = [];
  List<TrackedFile> _largeFiles = [];
  String? _errorMessage;

  bool get isScanning => _isScanning;
  double get scanProgress => _scanProgress;
  List<TrackedFile> get allFiles => _allFiles;
  List<TrackedFile> get oldFiles => _oldFiles;
  List<TrackedFile> get largeFiles => _largeFiles;
  String? get errorMessage => _errorMessage;

  // Request permissions
  Future<bool> requestPermissions() async {
    final PermissionState ps = await PhotoManager.requestPermissionExtend();
    if (ps.isAuth) {
      return true;
    } else if (ps.hasAccess) {
      return true;
    } else {
      _errorMessage = 'Permission denied. Please grant photo access in settings.';
      notifyListeners();
      return false;
    }
  }

  // Main scan function
  Future<void> scanFiles() async {
    if (_isScanning) return;

    _isScanning = true;
    _scanProgress = 0.0;
    _errorMessage = null;
    notifyListeners();

    try {
      // Check permissions
      final hasPermission = await requestPermissions();
      if (!hasPermission) {
        _isScanning = false;
        notifyListeners();
        return;
      }

      // Get all albums/folders
      final List<AssetPathEntity> albums = await PhotoManager.getAssetPathList(
        type: RequestType.common, // Photos and videos
        hasAll: true,
      );

      if (albums.isEmpty) {
        _errorMessage = 'No photos or videos found';
        _isScanning = false;
        notifyListeners();
        return;
      }

      // Clear existing data
      await DatabaseHelper.instance.clearAll();

      // Process all albums
      int totalProcessed = 0;
      int totalAssets = 0;

      // First, count total assets
      for (final album in albums) {
        totalAssets += await album.assetCountAsync;
      }

      // Process each album
      for (final album in albums) {
        final List<AssetEntity> assets = await album.getAssetListRange(
          start: 0,
          end: await album.assetCountAsync,
        );

        for (final asset in assets) {
          // Create tracked file from asset
          final trackedFile = await _createTrackedFileFromAsset(asset);
          if (trackedFile != null) {
            await DatabaseHelper.instance.insert(trackedFile);
          }

          totalProcessed++;
          _scanProgress = totalProcessed / totalAssets;
          
          // Update UI periodically
          if (totalProcessed % 50 == 0) {
            notifyListeners();
          }
        }
      }

      // Load files from database
      await loadFiles();

      _scanProgress = 1.0;
    } catch (e) {
      _errorMessage = 'Scan error: $e';
      debugPrint('Scan error: $e');
    } finally {
      _isScanning = false;
      notifyListeners();
    }
  }

  // Create TrackedFile from AssetEntity
  Future<TrackedFile?> _createTrackedFileFromAsset(AssetEntity asset) async {
    try {
      final file = await asset.file;
      if (file == null) return null;

      // Determine file type
      FileType fileType;
      if (asset.type == AssetType.video) {
        fileType = FileType.video;
      } else if (asset.title?.toLowerCase().contains('screenshot') ?? false) {
        fileType = FileType.screenshot;
      } else {
        fileType = FileType.photo;
      }

      // Get thumbnail path for display
      final thumbFile = await asset.thumbnailDataWithSize(
        const ThumbnailSize(200, 200),
      );

      return TrackedFile(
        id: asset.id,
        path: file.path,
        name: asset.title ?? 'Untitled',
        sizeBytes: await file.length(),
        createdDate: asset.createDateTime,
        lastAccessedDate: asset.modifiedDateTime,
        type: fileType,
        thumbnailPath: thumbFile != null ? 'memory' : null,
      );
    } catch (e) {
      debugPrint('Error creating tracked file: $e');
      return null;
    }
  }

  // Load files from database
  Future<void> loadFiles() async {
    try {
      _allFiles = await DatabaseHelper.instance.getAllFiles();
      _oldFiles = await DatabaseHelper.instance.getOldFiles(monthsOld: 6);
      _largeFiles = await DatabaseHelper.instance.getLargeFiles(minSizeMB: 50);
      notifyListeners();
    } catch (e) {
      _errorMessage = 'Error loading files: $e';
      debugPrint('Error loading files: $e');
      notifyListeners();
    }
  }

  // Delete a file
  Future<bool> deleteFile(TrackedFile file) async {
    try {
      // Delete from device
      final asset = await AssetEntity.fromId(file.id);
      if (asset != null) {
        final List<String> result = await PhotoManager.editor.deleteWithIds([asset.id]);
        if (result.isNotEmpty) {
          // Delete from database
          await DatabaseHelper.instance.delete(file.id);
          await loadFiles();
          return true;
        }
      }
      return false;
    } catch (e) {
      _errorMessage = 'Error deleting file: $e';
      debugPrint('Error deleting file: $e');
      notifyListeners();
      return false;
    }
  }

  // Delete multiple files
  Future<int> deleteMultipleFiles(List<TrackedFile> files) async {
    int deletedCount = 0;
    try {
      final List<String> assetIds = files.map((f) => f.id).toList();
      final List<String> result = await PhotoManager.editor.deleteWithIds(assetIds);
      
      deletedCount = result.length;
      
      // Delete from database
      await DatabaseHelper.instance.deleteMultiple(assetIds);
      await loadFiles();
    } catch (e) {
      _errorMessage = 'Error deleting files: $e';
      debugPrint('Error deleting files: $e');
      notifyListeners();
    }
    return deletedCount;
  }

  // Get storage statistics
  Future<Map<String, dynamic>> getStorageStats() async {
    final totalSize = await DatabaseHelper.instance.getTotalStorageUsed();
    final fileCount = await DatabaseHelper.instance.getFileCount();
    final oldFilesSize = _oldFiles.fold<int>(0, (sum, file) => sum + file.sizeBytes);
    final largeFilesSize = _largeFiles.fold<int>(0, (sum, file) => sum + file.sizeBytes);

    return {
      'totalSize': totalSize,
      'fileCount': fileCount,
      'oldFilesCount': _oldFiles.length,
      'oldFilesSize': oldFilesSize,
      'largeFilesCount': _largeFiles.length,
      'largeFilesSize': largeFilesSize,
    };
  }
}
