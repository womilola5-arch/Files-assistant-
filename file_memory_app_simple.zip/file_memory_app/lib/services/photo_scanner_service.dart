import 'dart:io';
import 'package:photo_manager/photo_manager.dart';
import '../models/tracked_file.dart';
import 'database_service.dart';

class PhotoScannerService {
  final DatabaseService _db = DatabaseService.instance;
  
  Future<bool> requestPermissions() async {
    final PermissionState ps = await PhotoManager.requestPermissionExtend();
    return ps.isAuth || ps.hasAccess;
  }

  Future<ScanResult> scanPhotosAndVideos({
    Function(int current, int total)? onProgress,
  }) async {
    List<TrackedFile> trackedFiles = [];
    int totalSize = 0;
    int photoCount = 0;
    int videoCount = 0;
    int screenshotCount = 0;

    try {
      final List<AssetPathEntity> albums = await PhotoManager.getAssetPathList(
        type: RequestType.common,
      );

      int totalAssets = 0;
      for (var album in albums) {
        totalAssets += await album.assetCountAsync;
      }

      int processedAssets = 0;

      for (var album in albums) {
        final int assetCount = await album.assetCountAsync;
        
        const int batchSize = 50;
        for (int i = 0; i < assetCount; i += batchSize) {
          final List<AssetEntity> assets = await album.getAssetListRange(
            start: i,
            end: (i + batchSize > assetCount) ? assetCount : i + batchSize,
          );

          for (var asset in assets) {
            final file = await asset.file;
            if (file == null) continue;

            FileType fileType;
            if (asset.type == AssetType.video) {
              fileType = FileType.video;
              videoCount++;
            } else {
              final isScreenshot = await _isScreenshot(asset, file);
              if (isScreenshot) {
                fileType = FileType.screenshot;
                screenshotCount++;
              } else {
                fileType = FileType.photo;
                photoCount++;
              }
            }

            final trackedFile = TrackedFile(
              id: asset.id,
              name: file.path.split('/').last,
              path: file.path,
              sizeBytes: await file.length(),
              createdDate: asset.createDateTime,
              lastAccessedDate: asset.modifiedDateTime,
              fileType: fileType,
            );

            trackedFiles.add(trackedFile);
            totalSize += trackedFile.sizeBytes;
            processedAssets++;
            
            if (onProgress != null) {
              onProgress(processedAssets, totalAssets);
            }
          }
        }
      }

      if (trackedFiles.isNotEmpty) {
        await _db.upsertFiles(trackedFiles);
      }

      return ScanResult(
        totalFiles: trackedFiles.length,
        photoCount: photoCount,
        videoCount: videoCount,
        screenshotCount: screenshotCount,
        totalSizeBytes: totalSize,
        success: true,
      );
    } catch (e) {
      return ScanResult(
        totalFiles: 0,
        photoCount: 0,
        videoCount: 0,
        screenshotCount: 0,
        totalSizeBytes: 0,
        success: false,
        errorMessage: e.toString(),
      );
    }
  }

  Future<bool> _isScreenshot(AssetEntity asset, File file) async {
    try {
      final fileName = file.path.toLowerCase();
      if (fileName.contains('screenshot') ||
          fileName.contains('screen_shot') ||
          fileName.contains('screen shot') ||
          file.path.contains('/Screenshots/')) {
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<List<TrackedFile>> getOldFiles(int monthsOld) async {
    return await _db.getOldFiles(monthsOld);
  }

  Future<List<TrackedFile>> getLargestFiles({int limit = 20}) async {
    return await _db.getLargestFiles(limit: limit);
  }

  Future<bool> deleteFile(TrackedFile file) async {
    try {
      final physicalFile = File(file.path);
      if (await physicalFile.exists()) {
        await physicalFile.delete();
      }
      await _db.deleteFile(file.id);
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<int> deleteFiles(List<TrackedFile> files) async {
    int deletedCount = 0;
    for (var file in files) {
      final success = await deleteFile(file);
      if (success) deletedCount++;
    }
    return deletedCount;
  }

  Future<StorageStats> getStorageStats() async {
    final totalStorage = await _db.getTotalStorageUsed();
    final storageByType = await _db.getStorageByType();
    final allFiles = await _db.getAllFiles();
    
    final sixMonthsAgo = DateTime.now().subtract(const Duration(days: 180));
    final oldFiles = allFiles.where((f) => f.createdDate.isBefore(sixMonthsAgo)).toList();
    
    final oldFilesSize = oldFiles.fold<int>(0, (sum, file) => sum + file.sizeBytes);

    return StorageStats(
      totalFiles: allFiles.length,
      totalSizeBytes: totalStorage,
      oldFilesCount: oldFiles.length,
      oldFilesSizeBytes: oldFilesSize,
      storageByType: storageByType,
    );
  }
}

class ScanResult {
  final int totalFiles;
  final int photoCount;
  final int videoCount;
  final int screenshotCount;
  final int totalSizeBytes;
  final bool success;
  final String? errorMessage;

  ScanResult({
    required this.totalFiles,
    required this.photoCount,
    required this.videoCount,
    required this.screenshotCount,
    required this.totalSizeBytes,
    required this.success,
    this.errorMessage,
  });

  String get formattedSize {
    if (totalSizeBytes < 1024 * 1024) {
      return '${(totalSizeBytes / 1024).toStringAsFixed(1)} KB';
    }
    if (totalSizeBytes < 1024 * 1024 * 1024) {
      return '${(totalSizeBytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(totalSizeBytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }
}

class StorageStats {
  final int totalFiles;
  final int totalSizeBytes;
  final int oldFilesCount;
  final int oldFilesSizeBytes;
  final Map<FileType, int> storageByType;

  StorageStats({
    required this.totalFiles,
    required this.totalSizeBytes,
    required this.oldFilesCount,
    required this.oldFilesSizeBytes,
    required this.storageByType,
  });

  String formatSize(int bytes) {
    if (bytes < 1024 * 1024) {
      return '${(bytes / 1024).toStringAsFixed(1)} KB';
    }
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  double get oldFilesPercentage {
    if (totalFiles == 0) return 0;
    return (oldFilesCount / totalFiles) * 100;
  }

  double get oldFilesSizePercentage {
    if (totalSizeBytes == 0) return 0;
    return (oldFilesSizeBytes / totalSizeBytes) * 100;
  }
}
