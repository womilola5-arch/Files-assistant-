import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/foundation.dart';

class NotificationService {
  static final NotificationService instance = NotificationService._init();
  final FlutterLocalNotificationsPlugin _notifications = FlutterLocalNotificationsPlugin();

  NotificationService._init();

  Future<void> initialize() async {
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    // Request permissions for iOS
    if (defaultTargetPlatform == TargetPlatform.iOS) {
      await _notifications
          .resolvePlatformSpecificImplementation<
              IOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(
            alert: true,
            badge: true,
            sound: true,
          );
    }

    // Request permissions for Android 13+
    if (defaultTargetPlatform == TargetPlatform.android) {
      await _notifications
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
    }
  }

  void _onNotificationTapped(NotificationResponse response) {
    debugPrint('Notification tapped: ${response.payload}');
    // Handle notification tap - navigate to specific screen
  }

  // Show notification for old files
  Future<void> showOldFilesNotification({
    required int fileCount,
    required String totalSize,
  }) async {
    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'old_files_channel',
      'Old Files Notifications',
      channelDescription: 'Notifications about old files on your device',
      importance: Importance.high,
      priority: Priority.high,
      styleInformation: BigTextStyleInformation(''),
    );

    const DarwinNotificationDetails iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const NotificationDetails details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notifications.show(
      0,
      'Old Files Found',
      'You have $fileCount files older than 6 months ($totalSize). Tap to review and free up space.',
      details,
      payload: 'old_files',
    );
  }

  // Show notification for large files
  Future<void> showLargeFilesNotification({
    required int fileCount,
    required String totalSize,
  }) async {
    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'large_files_channel',
      'Large Files Notifications',
      channelDescription: 'Notifications about large files on your device',
      importance: Importance.high,
      priority: Priority.high,
    );

    const DarwinNotificationDetails iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const NotificationDetails details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notifications.show(
      1,
      'Large Files Found',
      'You have $fileCount large files taking up $totalSize. Consider cleaning them up.',
      details,
      payload: 'large_files',
    );
  }

  // Schedule weekly reminder
  // Note: This requires additional setup for periodic notifications
  Future<void> scheduleWeeklyReminder() async {
    // Implementation would use workmanager or similar package
    // for background tasks in production
    debugPrint('Weekly reminder scheduled');
  }

  // Cancel all notifications
  Future<void> cancelAll() async {
    await _notifications.cancelAll();
  }
}
