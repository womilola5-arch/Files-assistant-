import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/tracked_file.dart';

class DatabaseService {
  static final DatabaseService instance = DatabaseService._init();
  static Database? _database;

  DatabaseService._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('file_memory.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    const idType = 'TEXT PRIMARY KEY';
    const textType = 'TEXT NOT NULL';
    const intType = 'INTEGER NOT NULL';

    await db.execute('''
      CREATE TABLE tracked_files (
        id $idType,
        name $textType,
        path $textType,
        sizeBytes $intType,
        createdDate $textType,
        lastAccessedDate $textType,
        fileType $textType,
        isMarkedForDeletion $intType,
        thumbnailPath TEXT
      )
    ''');

    await db.execute('''
      CREATE INDEX idx_created_date ON tracked_files(createdDate)
    ''');
    
    await db.execute('''
      CREATE INDEX idx_file_type ON tracked_files(fileType)
    ''');
  }

  Future<void> upsertFile(TrackedFile file) async {
    final db = await instance.database;
    await db.insert(
      'tracked_files',
      file.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> upsertFiles(List<TrackedFile> files) async {
    final db = await instance.database;
    final batch = db.batch();
    
    for (var file in files) {
      batch.insert(
        'tracked_files',
        file.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    
    await batch.commit(noResult: true);
  }

  Future<List<TrackedFile>> getAllFiles() async {
    final db = await instance.database;
    final result = await db.query('tracked_files');
    return result.map((map) => TrackedFile.fromMap(map)).toList();
  }

  Future<List<TrackedFile>> getOldFiles(int monthsOld) async {
    final db = await instance.database;
    final cutoffDate = DateTime.now().subtract(Duration(days: monthsOld * 30));
    
    final result = await db.query(
      'tracked_files',
      where: 'createdDate < ?',
      whereArgs: [cutoffDate.toIso8601String()],
      orderBy: 'sizeBytes DESC',
    );
    
    return result.map((map) => TrackedFile.fromMap(map)).toList();
  }

  Future<List<TrackedFile>> getFilesByType(FileType type) async {
    final db = await instance.database;
    final result = await db.query(
      'tracked_files',
      where: 'fileType = ?',
      whereArgs: [type.toString()],
    );
    
    return result.map((map) => TrackedFile.fromMap(map)).toList();
  }

  Future<List<TrackedFile>> getLargestFiles({int limit = 20}) async {
    final db = await instance.database;
    final result = await db.query(
      'tracked_files',
      orderBy: 'sizeBytes DESC',
      limit: limit,
    );
    
    return result.map((map) => TrackedFile.fromMap(map)).toList();
  }

  Future<void> deleteFile(String id) async {
    final db = await instance.database;
    await db.delete(
      'tracked_files',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> deleteFiles(List<String> ids) async {
    final db = await instance.database;
    final batch = db.batch();
    
    for (var id in ids) {
      batch.delete(
        'tracked_files',
        where: 'id = ?',
        whereArgs: [id],
      );
    }
    
    await batch.commit(noResult: true);
  }

  Future<int> getTotalStorageUsed() async {
    final db = await instance.database;
    final result = await db.rawQuery(
      'SELECT SUM(sizeBytes) as total FROM tracked_files'
    );
    
    return result.first['total'] as int? ?? 0;
  }

  Future<Map<FileType, int>> getStorageByType() async {
    final db = await instance.database;
    final result = await db.rawQuery(
      'SELECT fileType, SUM(sizeBytes) as total FROM tracked_files GROUP BY fileType'
    );
    
    Map<FileType, int> storageMap = {};
    
    for (var row in result) {
      final typeString = row['fileType'] as String;
      final total = row['total'] as int;
      final type = FileType.values.firstWhere(
        (e) => e.toString() == typeString,
        orElse: () => FileType.other,
      );
      storageMap[type] = total;
    }
    
    return storageMap;
  }

  Future<void> clearAllFiles() async {
    final db = await instance.database;
    await db.delete('tracked_files');
  }

  Future<void> close() async {
    final db = await instance.database;
    await db.close();
  }
}
