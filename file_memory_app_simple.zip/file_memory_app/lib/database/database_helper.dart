import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/tracked_file.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('file_memory.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    const idType = 'TEXT PRIMARY KEY';
    const textType = 'TEXT NOT NULL';
    const intType = 'INTEGER NOT NULL';
    const boolType = 'INTEGER NOT NULL';

    await db.execute('''
      CREATE TABLE tracked_files (
        id $idType,
        path $textType,
        name $textType,
        sizeBytes $intType,
        createdDate $intType,
        lastAccessedDate INTEGER,
        type $intType,
        thumbnailPath TEXT,
        isMarkedForDeletion $boolType
      )
    ''');

    // Create index for faster queries
    await db.execute('''
      CREATE INDEX idx_created_date ON tracked_files(createdDate)
    ''');
  }

  // Insert a tracked file
  Future<TrackedFile> insert(TrackedFile file) async {
    final db = await instance.database;
    await db.insert('tracked_files', file.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
    return file;
  }

  // Get all tracked files
  Future<List<TrackedFile>> getAllFiles() async {
    final db = await instance.database;
    const orderBy = 'createdDate DESC';
    final result = await db.query('tracked_files', orderBy: orderBy);
    return result.map((json) => TrackedFile.fromMap(json)).toList();
  }

  // Get old files (6+ months)
  Future<List<TrackedFile>> getOldFiles({int monthsOld = 6}) async {
    final db = await instance.database;
    final cutoffDate = DateTime.now().subtract(Duration(days: monthsOld * 30));
    final cutoffTimestamp = cutoffDate.millisecondsSinceEpoch;

    final result = await db.query(
      'tracked_files',
      where: 'createdDate <= ?',
      whereArgs: [cutoffTimestamp],
      orderBy: 'createdDate ASC',
    );

    return result.map((json) => TrackedFile.fromMap(json)).toList();
  }

  // Get large files
  Future<List<TrackedFile>> getLargeFiles({int minSizeMB = 50}) async {
    final db = await instance.database;
    final minSizeBytes = minSizeMB * 1024 * 1024;

    final result = await db.query(
      'tracked_files',
      where: 'sizeBytes >= ?',
      whereArgs: [minSizeBytes],
      orderBy: 'sizeBytes DESC',
    );

    return result.map((json) => TrackedFile.fromMap(json)).toList();
  }

  // Get files by type
  Future<List<TrackedFile>> getFilesByType(FileType type) async {
    final db = await instance.database;
    final result = await db.query(
      'tracked_files',
      where: 'type = ?',
      whereArgs: [type.index],
      orderBy: 'createdDate DESC',
    );

    return result.map((json) => TrackedFile.fromMap(json)).toList();
  }

  // Update a file
  Future<int> update(TrackedFile file) async {
    final db = await instance.database;
    return db.update(
      'tracked_files',
      file.toMap(),
      where: 'id = ?',
      whereArgs: [file.id],
    );
  }

  // Delete a file from database
  Future<int> delete(String id) async {
    final db = await instance.database;
    return await db.delete(
      'tracked_files',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Delete multiple files
  Future<int> deleteMultiple(List<String> ids) async {
    final db = await instance.database;
    final placeholders = List.filled(ids.length, '?').join(',');
    return await db.delete(
      'tracked_files',
      where: 'id IN ($placeholders)',
      whereArgs: ids,
    );
  }

  // Get total storage used
  Future<int> getTotalStorageUsed() async {
    final db = await instance.database;
    final result = await db.rawQuery('SELECT SUM(sizeBytes) as total FROM tracked_files');
    return (result.first['total'] as int?) ?? 0;
  }

  // Get count of files
  Future<int> getFileCount() async {
    final db = await instance.database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM tracked_files');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  // Clear all data
  Future<void> clearAll() async {
    final db = await instance.database;
    await db.delete('tracked_files');
  }

  // Close database
  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
