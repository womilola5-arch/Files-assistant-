import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/file_scanner_service.dart';
import '../models/tracked_file.dart';
import 'file_list_screen.dart';
import '../widgets/storage_card.dart';
import '../widgets/category_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // Load existing data
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<FileScannerService>().loadFiles();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('File Memory'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              // Navigate to settings
              _showSettingsDialog(context);
            },
          ),
        ],
      ),
      body: Consumer<FileScannerService>(
        builder: (context, scannerService, child) {
          if (scannerService.isScanning) {
            return _buildScanningView(scannerService);
          }

          if (scannerService.errorMessage != null) {
            return _buildErrorView(scannerService);
          }

          if (scannerService.allFiles.isEmpty) {
            return _buildEmptyView(context, scannerService);
          }

          return _buildContentView(context, scannerService);
        },
      ),
      floatingActionButton: Consumer<FileScannerService>(
        builder: (context, scannerService, child) {
          return FloatingActionButton.extended(
            onPressed: scannerService.isScanning
                ? null
                : () => scannerService.scanFiles(),
            icon: const Icon(Icons.refresh),
            label: const Text('Scan Files'),
          );
        },
      ),
    );
  }

  Widget _buildScanningView(FileScannerService service) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircularProgressIndicator(),
          const SizedBox(height: 24),
          Text(
            'Scanning your files...',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 12),
          Text(
            '${(service.scanProgress * 100).toStringAsFixed(0)}% complete',
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          const SizedBox(height: 24),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 48.0),
            child: LinearProgressIndicator(value: service.scanProgress),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorView(FileScannerService service) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.red),
            const SizedBox(height: 16),
            Text(
              'Error',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            Text(
              service.errorMessage ?? 'An unknown error occurred',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () => service.scanFiles(),
              icon: const Icon(Icons.refresh),
              label: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyView(BuildContext context, FileScannerService service) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.folder_open,
              size: 80,
              color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
            ),
            const SizedBox(height: 24),
            Text(
              'No Files Scanned Yet',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 12),
            Text(
              'Tap the scan button below to discover files on your device',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContentView(BuildContext context, FileScannerService service) {
    return FutureBuilder<Map<String, dynamic>>(
      future: service.getStorageStats(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final stats = snapshot.data!;

        return RefreshIndicator(
          onRefresh: () => service.scanFiles(),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // Storage Overview Card
              StorageCard(
                totalSize: stats['totalSize'] as int,
                fileCount: stats['fileCount'] as int,
              ),
              const SizedBox(height: 16),

              // Old Files Category
              CategoryCard(
                title: 'Old Files',
                subtitle: '6+ months old',
                fileCount: service.oldFiles.length,
                totalSize: stats['oldFilesSize'] as int,
                icon: Icons.schedule,
                color: Colors.orange,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FileListScreen(
                        title: 'Old Files',
                        files: service.oldFiles,
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 12),

              // Large Files Category
              CategoryCard(
                title: 'Large Files',
                subtitle: '50+ MB each',
                fileCount: service.largeFiles.length,
                totalSize: stats['largeFilesSize'] as int,
                icon: Icons.storage,
                color: Colors.red,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FileListScreen(
                        title: 'Large Files',
                        files: service.largeFiles,
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 12),

              // Photos Category
              CategoryCard(
                title: 'All Photos',
                subtitle: 'View all your photos',
                fileCount: service.allFiles.where((f) => f.type == FileType.photo).length,
                totalSize: service.allFiles
                    .where((f) => f.type == FileType.photo)
                    .fold<int>(0, (sum, file) => sum + file.sizeBytes),
                icon: Icons.photo,
                color: Colors.blue,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FileListScreen(
                        title: 'Photos',
                        files: service.allFiles
                            .where((f) => f.type == FileType.photo)
                            .toList(),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 12),

              // Videos Category
              CategoryCard(
                title: 'All Videos',
                subtitle: 'View all your videos',
                fileCount: service.allFiles.where((f) => f.type == FileType.video).length,
                totalSize: service.allFiles
                    .where((f) => f.type == FileType.video)
                    .fold<int>(0, (sum, file) => sum + file.sizeBytes),
                icon: Icons.videocam,
                color: Colors.purple,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FileListScreen(
                        title: 'Videos',
                        files: service.allFiles
                            .where((f) => f.type == FileType.video)
                            .toList(),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 80), // Space for FAB
            ],
          ),
        );
      },
    );
  }

  void _showSettingsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Settings'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('File Memory v1.0.0'),
            SizedBox(height: 8),
            Text('Discover and manage forgotten files'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}
