import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:photo_manager/photo_manager.dart';
import '../models/tracked_file.dart';
import '../services/file_scanner_service.dart';
import 'file_detail_screen.dart';

class FileListScreen extends StatefulWidget {
  final String title;
  final List<TrackedFile> files;

  const FileListScreen({
    super.key,
    required this.title,
    required this.files,
  });

  @override
  State<FileListScreen> createState() => _FileListScreenState();
}

class _FileListScreenState extends State<FileListScreen> {
  final Set<String> _selectedFiles = {};
  bool _isSelectionMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          if (_isSelectionMode)
            TextButton(
              onPressed: () {
                setState(() {
                  _selectedFiles.clear();
                  _isSelectionMode = false;
                });
              },
              child: const Text('Cancel'),
            )
          else
            IconButton(
              icon: const Icon(Icons.select_all),
              onPressed: () {
                setState(() {
                  _isSelectionMode = true;
                });
              },
            ),
        ],
      ),
      body: widget.files.isEmpty
          ? _buildEmptyView()
          : _buildFileList(),
      bottomNavigationBar: _isSelectionMode && _selectedFiles.isNotEmpty
          ? _buildBottomBar()
          : null,
    );
  }

  Widget _buildEmptyView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.check_circle_outline,
            size: 64,
            color: Colors.green.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'No files in this category',
            style: Theme.of(context).textTheme.titleLarge,
          ),
        ],
      ),
    );
  }

  Widget _buildFileList() {
    return ListView.builder(
      itemCount: widget.files.length,
      itemBuilder: (context, index) {
        final file = widget.files[index];
        final isSelected = _selectedFiles.contains(file.id);

        return ListTile(
          leading: _buildFileThumbnail(file),
          title: Text(
            file.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: Text('${file.ageString} • ${file.sizeString}'),
          trailing: _isSelectionMode
              ? Checkbox(
                  value: isSelected,
                  onChanged: (value) {
                    setState(() {
                      if (value == true) {
                        _selectedFiles.add(file.id);
                      } else {
                        _selectedFiles.remove(file.id);
                      }
                    });
                  },
                )
              : Icon(
                  file.type == FileType.video
                      ? Icons.videocam
                      : Icons.photo,
                  color: Colors.grey,
                ),
          onTap: () {
            if (_isSelectionMode) {
              setState(() {
                if (isSelected) {
                  _selectedFiles.remove(file.id);
                } else {
                  _selectedFiles.add(file.id);
                }
              });
            } else {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FileDetailScreen(file: file),
                ),
              );
            }
          },
          onLongPress: () {
            if (!_isSelectionMode) {
              setState(() {
                _isSelectionMode = true;
                _selectedFiles.add(file.id);
              });
            }
          },
        );
      },
    );
  }

  Widget _buildFileThumbnail(TrackedFile file) {
    return FutureBuilder<AssetEntity?>(
      future: AssetEntity.fromId(file.id),
      builder: (context, snapshot) {
        if (snapshot.hasData && snapshot.data != null) {
          return AssetEntityImage(
            snapshot.data!,
            width: 50,
            height: 50,
            fit: BoxFit.cover,
            isOriginal: false,
          );
        }
        return Container(
          width: 50,
          height: 50,
          color: Colors.grey[300],
          child: Icon(
            file.type == FileType.video ? Icons.videocam : Icons.photo,
            color: Colors.grey[600],
          ),
        );
      },
    );
  }

  Widget _buildBottomBar() {
    final selectedCount = _selectedFiles.length;
    final selectedSize = widget.files
        .where((f) => _selectedFiles.contains(f.id))
        .fold<int>(0, (sum, file) => sum + file.sizeBytes);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$selectedCount selected',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                Text(
                  _formatSize(selectedSize),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          ElevatedButton.icon(
            onPressed: () => _confirmDelete(),
            icon: const Icon(Icons.delete),
            label: const Text('Delete'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  String _formatSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) {
      return '${(bytes / 1024).toStringAsFixed(1)} KB';
    }
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  void _confirmDelete() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Files'),
        content: Text(
          'Are you sure you want to delete ${_selectedFiles.length} file(s)? This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteSelectedFiles();
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteSelectedFiles() async {
    final scannerService = context.read<FileScannerService>();
    final filesToDelete = widget.files
        .where((f) => _selectedFiles.contains(f.id))
        .toList();

    // Show loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(),
      ),
    );

    final deletedCount = await scannerService.deleteMultipleFiles(filesToDelete);

    if (mounted) {
      Navigator.pop(context); // Close loading dialog

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Deleted $deletedCount file(s)'),
          backgroundColor: Colors.green,
        ),
      );

      setState(() {
        _selectedFiles.clear();
        _isSelectionMode = false;
      });

      // Go back if all files deleted
      if (deletedCount == widget.files.length) {
        Navigator.pop(context);
      }
    }
  }
}
