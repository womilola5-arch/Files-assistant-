# Development Commands Cheat Sheet

## Essential Flutter Commands

### Setup & Installation
```bash
# Check Flutter installation
flutter doctor

# Accept Android licenses
flutter doctor --android-licenses

# Install dependencies
flutter pub get

# Repair pub cache (if issues)
flutter pub cache repair

# Clean build files
flutter clean
```

### Running the App
```bash
# List available devices
flutter devices

# Run on first available device
flutter run

# Run on specific device
flutter run -d <device-id>

# Run in debug mode (default)
flutter run

# Run in profile mode (performance testing)
flutter run --profile

# Run in release mode
flutter run --release

# Hot reload during development
# Press 'r' in terminal while app is running

# Hot restart
# Press 'R' in terminal while app is running
```

### Building
```bash
# Build Android APK (debug)
flutter build apk --debug

# Build Android APK (release)
flutter build apk --release

# Build Android App Bundle (for Play Store)
flutter build appbundle --release

# Build iOS (requires macOS and Xcode)
flutter build ios --release

# Build for both platforms
flutter build apk --release && flutter build ios --release
```

### Testing & Debugging
```bash
# Run tests
flutter test

# Analyze code for issues
flutter analyze

# Format code
flutter format .

# Run with verbose logging
flutter run -v

# Open DevTools
flutter pub global activate devtools
flutter pub global run devtools
```

### Package Management
```bash
# Add a new package
flutter pub add package_name

# Remove a package
flutter pub remove package_name

# Update packages
flutter pub upgrade

# Get outdated packages
flutter pub outdated
```

### Platform-Specific

#### Android
```bash
# Open Android project in Android Studio
open -a "Android Studio" android/

# Gradle clean
cd android
./gradlew clean
cd ..

# Check APK size
cd build/app/outputs/flutter-apk/
ls -lh app-release.apk
```

#### iOS (macOS only)
```bash
# Install CocoaPods dependencies
cd ios
pod install
cd ..

# Update pods
cd ios
pod update
cd ..

# Open in Xcode
open ios/Runner.xcworkspace

# Clean iOS build
cd ios
rm -rf Pods
rm Podfile.lock
pod install
cd ..
```

### Useful Development Commands
```bash
# Show app size breakdown
flutter build apk --analyze-size

# Generate app icons
flutter pub run flutter_launcher_icons:main

# Generate splash screens
flutter pub run flutter_native_splash:create

# Check dependencies tree
flutter pub deps

# Run app and open DevTools
flutter run --start-paused
```

### Database Commands (SQLite)
```bash
# Install sqlite3 CLI (for debugging)
# macOS
brew install sqlite3

# Linux
sudo apt-get install sqlite3

# Access app database (while app is running)
# First, find the database path in app logs
adb shell
run-as com.your.package.name
cd databases
sqlite3 file_memory.db

# Common SQL commands in sqlite3
.tables          # List all tables
.schema          # Show table schemas
SELECT * FROM tracked_files LIMIT 10;  # Query data
.exit            # Exit sqlite3
```

### Debugging Specific Issues

#### Permission Issues
```bash
# Grant permissions manually (Android)
adb shell pm grant com.your.package.name android.permission.READ_EXTERNAL_STORAGE

# Check granted permissions
adb shell dumpsys package com.your.package.name | grep permission
```

#### Clear App Data
```bash
# Android
adb shell pm clear com.your.package.name

# iOS (in Simulator)
# Delete app and reinstall
```

#### View Logs
```bash
# Android logs
adb logcat

# Filter for Flutter logs
adb logcat | grep flutter

# iOS logs (in Xcode)
# Window > Devices and Simulators > View Device Logs
```

### Performance Profiling
```bash
# Run in profile mode
flutter run --profile

# Run with timeline trace
flutter run --profile --trace-startup

# Capture performance overlay
# Press 'P' while app is running

# Check for slow frames
# Press 'S' while app is running
```

### CI/CD Commands
```bash
# Run all checks before commit
flutter analyze && flutter test && flutter build apk --release

# Create git ignore
flutter create --platforms=android,ios .
```

### Quick Fixes

#### "Gradle sync failed"
```bash
cd android
./gradlew clean
cd ..
flutter clean
flutter pub get
```

#### "CocoaPods error"
```bash
cd ios
rm -rf Pods Podfile.lock
pod install
cd ..
flutter clean
flutter run
```

#### "Dependency conflict"
```bash
flutter pub cache clean
flutter pub get
```

#### "White screen on launch"
```bash
flutter clean
flutter pub get
flutter run --release
```

### Build Size Optimization
```bash
# Enable code shrinking (Android)
# Already enabled in app/build.gradle

# Analyze APK
flutter build apk --analyze-size --target-platform android-arm64

# Remove unused resources
# Add to android/app/build.gradle:
# android.buildTypes.release.shrinkResources true
```

---

## Quick Reference

**Most Used Commands:**
```bash
flutter run              # Run app
flutter clean            # Clean build
flutter pub get          # Install dependencies
flutter build apk        # Build Android APK
flutter doctor           # Check setup
```

**During Development:**
```bash
r     # Hot reload
R     # Hot restart
p     # Grid overlay
P     # Performance overlay
q     # Quit
```

---

## Environment Variables

```bash
# Set Flutter SDK path
export PATH="$PATH:/path/to/flutter/bin"

# Set Java home (if needed)
export JAVA_HOME=/path/to/jdk

# Set Android SDK path
export ANDROID_HOME=/path/to/android-sdk
export PATH="$PATH:$ANDROID_HOME/platform-tools"
```

Save these to `~/.bashrc` or `~/.zshrc` for persistence.

---

**Pro Tip:** Create aliases for common commands:

```bash
# Add to ~/.bashrc or ~/.zshrc
alias fr='flutter run'
alias fc='flutter clean'
alias fpg='flutter pub get'
alias fba='flutter build apk --release'
```

---

Remember: Always run `flutter pub get` after adding/updating dependencies!
