# Changelog

All notable changes to the File Memory app will be documented in this file.

## [1.0.0] - 2025-02-19

### Added
- Initial release of File Memory app
- Photo and video scanning functionality
- Old files detection (6+ months)
- Large files detection (50+ MB)
- Storage analytics and breakdown
- File categorization (Photos, Videos, Screenshots)
- Individual file detail view
- Batch file deletion
- Single file deletion
- Storage usage statistics
- Material Design 3 UI
- Dark mode support
- SQLite local database for file tracking
- Local notification system
- Permission handling for Android and iOS
- Cross-platform support (Android & iOS)

### Features
- **Smart Scanning**: Automatically discovers all photos and videos
- **Storage Insights**: Visual breakdown of storage usage
- **Easy Cleanup**: Simple interface to review and delete files
- **Safe Operations**: Confirmation dialogs before deletion
- **Progress Tracking**: Real-time scan progress indicator
- **Multi-select**: Select multiple files for batch operations

### Technical
- Built with Flutter 3.0+
- State management using Provider
- Local database using SQLite
- Photo access using photo_manager package
- Notification support using flutter_local_notifications
- Permission handling using permission_handler

## Future Versions (Planned)

### [1.1.0] - Planned
- Duplicate photo detection
- Similar photo grouping
- Advanced filtering options
- Sort by various criteria (size, date, type)
- Export file lists
- Share functionality

### [1.2.0] - Planned
- Cloud backup integration (Google Drive, iCloud)
- Automatic cleanup scheduling
- Weekly/monthly storage reports
- Customizable cleanup rules
- More file types support (documents, downloads, audio)

### [2.0.0] - Planned
- AI-powered duplicate detection
- Smart recommendations
- Storage optimization suggestions
- Widget support
- Tablet optimization
- Multi-language support

## Version History Format

### [Version Number] - Date
**Added** - New features
**Changed** - Changes in existing functionality
**Deprecated** - Features that will be removed
**Removed** - Removed features
**Fixed** - Bug fixes
**Security** - Security improvements
