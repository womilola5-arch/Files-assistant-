# Quick Start Guide - File Memory App

## 🚀 Get Started in 5 Steps

### Step 1: Install Flutter

**Windows:**
1. Download Flutter SDK: https://docs.flutter.dev/get-started/install/windows
2. Extract to `C:\src\flutter`
3. Add to PATH: `C:\src\flutter\bin`
4. Run `flutter doctor` in terminal

**macOS:**
```bash
# Using Homebrew
brew install flutter

# Or download manually from flutter.dev
```

**Linux:**
```bash
# Download Flutter
cd ~
wget https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.x.x-stable.tar.xz

# Extract
tar xf flutter_linux_3.x.x-stable.tar.xz

# Add to PATH
echo 'export PATH="$PATH:`pwd`/flutter/bin"' >> ~/.bashrc
source ~/.bashrc
```

### Step 2: Install IDE (Choose One)

**Option A: Android Studio (Recommended)**
1. Download: https://developer.android.com/studio
2. Install Android SDK
3. Install Flutter & Dart plugins
4. Configure Android emulator

**Option B: VS Code**
1. Download: https://code.visualstudio.com/
2. Install "Flutter" extension
3. Install "Dart" extension

### Step 3: Verify Installation

```bash
flutter doctor
```

Fix any issues shown (Android licenses, Xcode, etc.)

For Android licenses:
```bash
flutter doctor --android-licenses
```

### Step 4: Set Up the Project

```bash
# Navigate to project folder
cd file_memory_app

# Get dependencies
flutter pub get

# Check for devices
flutter devices
```

### Step 5: Run the App

**On Android Emulator:**
```bash
# Start emulator from Android Studio, then:
flutter run
```

**On Physical Android Device:**
1. Enable Developer Mode on your phone
2. Enable USB Debugging
3. Connect via USB
4. Run: `flutter run`

**On iOS Simulator (macOS only):**
```bash
open -a Simulator
flutter run
```

**On Physical iPhone (macOS only):**
1. Open project in Xcode: `open ios/Runner.xcworkspace`
2. Set your Apple Developer team
3. Connect iPhone
4. Run: `flutter run`

---

## 📱 Testing the App

### First Launch Checklist:
1. ✅ App opens without errors
2. ✅ Welcome screen displays
3. ✅ Tap "Start Scanning"
4. ✅ Grant photo permissions when prompted
5. ✅ Scan completes successfully
6. ✅ Dashboard shows statistics
7. ✅ Tap "Old Files" to view list
8. ✅ Try deleting a test file

---

## 🐛 Common Setup Issues

### Issue: "Flutter not found"
**Solution:**
```bash
# Check PATH
echo $PATH  # Should include flutter/bin

# Re-add to PATH
export PATH="$PATH:/path/to/flutter/bin"
```

### Issue: "Android licenses not accepted"
**Solution:**
```bash
flutter doctor --android-licenses
# Accept all licenses
```

### Issue: "No devices found"
**Solution:**
- Start an emulator from Android Studio
- Or connect a physical device with USB debugging
- Check: `flutter devices`

### Issue: "CocoaPods not installed" (iOS/macOS)
**Solution:**
```bash
sudo gem install cocoapods
cd ios
pod install
cd ..
```

### Issue: "Gradle sync failed" (Android)
**Solution:**
```bash
cd android
./gradlew clean
cd ..
flutter clean
flutter pub get
flutter run
```

---

## 📦 Package Issues

If you get dependency errors:

```bash
# Clean everything
flutter clean

# Remove pub cache
flutter pub cache repair

# Get dependencies again
flutter pub get

# Try running
flutter run
```

---

## 🎯 Next Steps

Once the app is running:

1. **Customize the UI** - Edit `lib/screens/home_screen.dart`
2. **Add features** - Check README.md for enhancement ideas
3. **Test on real device** - Best for accurate performance
4. **Build release version** - `flutter build apk` or `flutter build ios`

---

## 🆘 Need More Help?

- Flutter Documentation: https://docs.flutter.dev
- Flutter Community: https://flutter.dev/community
- Stack Overflow: Tag your questions with 'flutter'
- This project's README.md for detailed documentation

---

## ✅ Success Checklist

Before considering setup complete:

- [ ] `flutter doctor` shows no errors
- [ ] App runs on emulator/simulator
- [ ] Photo permissions work correctly
- [ ] Scanning completes without crashes
- [ ] Files display in the list
- [ ] Deletion functionality works
- [ ] Notifications appear (if enabled)

---

**Happy coding! 🎉**
