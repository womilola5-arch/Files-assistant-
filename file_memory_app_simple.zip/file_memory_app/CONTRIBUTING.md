# Contributing to File Memory

Thank you for considering contributing to File Memory! This document provides guidelines for contributing to the project.

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check existing issues to avoid duplicates. When creating a bug report, include:

- **Clear title and description**
- **Steps to reproduce** the issue
- **Expected behavior** vs **actual behavior**
- **Screenshots** if applicable
- **Device information** (Android/iOS version, device model)
- **App version**

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion, include:

- **Clear title and description**
- **Use case** - why is this enhancement needed?
- **Proposed solution** - how should it work?
- **Alternative solutions** you've considered
- **Mockups or examples** if applicable

### Pull Requests

1. Fork the repository
2. Create a new branch (`git checkout -b feature/YourFeature`)
3. Make your changes
4. Test your changes thoroughly
5. Commit your changes (`git commit -m 'Add some feature'`)
6. Push to the branch (`git push origin feature/YourFeature`)
7. Open a Pull Request

#### Pull Request Guidelines

- **One feature per PR** - Keep PRs focused on a single feature or fix
- **Write clear commit messages** - Explain what and why, not just what
- **Update documentation** - If you add/change features, update README
- **Add tests** if applicable
- **Follow existing code style**
- **Make sure all tests pass**

## Development Process

### Setting Up Development Environment

1. Install Flutter SDK (see SETUP_GUIDE.md)
2. Clone your fork
3. Install dependencies: `flutter pub get`
4. Run the app: `flutter run`

### Code Style

We follow the official [Dart style guide](https://dart.dev/guides/language/effective-dart/style):

- Use `lowerCamelCase` for variables, functions, and parameters
- Use `UpperCamelCase` for class names
- Use `lowercase_with_underscores` for file names
- Format code: `dart format lib/`
- Analyze code: `flutter analyze`

### Commit Message Guidelines

Follow the conventional commits format:

```
type(scope): subject

body

footer
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, etc.)
- `refactor`: Code refactoring
- `test`: Adding or updating tests
- `chore`: Maintenance tasks

**Examples:**
```
feat(scanner): add duplicate file detection

Implements algorithm to detect duplicate files based on file hash.
Adds new UI component to display duplicate groups.

Closes #123
```

### Testing

- Write tests for new features
- Run tests before submitting PR: `flutter test`
- Test on both Android and iOS if possible
- Test on different Android/iOS versions
- Test on different screen sizes

### Documentation

- Update README.md if you add new features
- Add inline code comments for complex logic
- Update CHANGELOG.md for your changes
- Add/update screenshots if UI changes

## Project Structure

```
lib/
├── main.dart              # App entry point
├── models/                # Data models
├── services/              # Business logic
├── database/              # Database operations
├── screens/               # UI screens
├── widgets/               # Reusable widgets
└── utils/                 # Utility functions
```

### Key Files

- **models/tracked_file.dart** - File data model
- **services/file_scanner_service.dart** - Scanning logic
- **database/database_helper.dart** - Database operations
- **screens/home_screen.dart** - Main app screen

## Feature Development Workflow

1. **Discuss** - Open an issue to discuss the feature first
2. **Design** - Plan the implementation
3. **Implement** - Write the code
4. **Test** - Test thoroughly
5. **Document** - Update documentation
6. **Submit** - Create pull request

## Code Review Process

1. Maintainers review PRs within 1-2 weeks
2. Respond to feedback and make requested changes
3. Once approved, PR will be merged
4. Your contribution will be included in the next release

## Priority Areas for Contribution

We especially welcome contributions in these areas:

### High Priority
- 🐛 Bug fixes
- 📱 Platform-specific improvements
- 🎨 UI/UX enhancements
- ⚡ Performance optimizations
- 🧪 Test coverage

### Medium Priority
- 📷 Duplicate photo detection
- 📊 Advanced analytics
- 🔄 Cloud backup integration
- 🌍 Internationalization (i18n)
- ♿ Accessibility improvements

### Nice to Have
- 🎨 Themes and customization
- 📝 Additional file type support
- 🤖 ML-powered features
- 📱 Widget support
- 🎮 Animations and transitions

## Questions?

- Open an issue for questions about contributing
- Check existing issues and pull requests first
- Be respectful and constructive in discussions

## Recognition

Contributors will be:
- Listed in the README
- Mentioned in release notes
- Part of a growing community

Thank you for contributing to File Memory! 🎉
